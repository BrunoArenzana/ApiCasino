export abstract class Juegos{
    abstract jugar(): void;   
     
}