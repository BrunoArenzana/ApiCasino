export interface iApostar {
  
apuestaMinimaMaxima(minima: number, maxima: number): void;

}