# ApiCasino
Casino es un juego creado para la entraga del Trabajo Practico Final del segundo cuatrimestre de la Carrera Full Stack dictada por CEPIT
Se implemento codigo typescript en el entorno de ejecucion nodejs.
Se transpilo el codigo a JavaScrip.
Se utilizaron modulos como file-system y readline-sync.


-----------
# ApiCasino
Final Cuatrimestre

ApiCasino Pertenece al grupo Error404 (Querian,Marcelo  y Bruno)
Se trata del desarrollo de una aplicacion que consta con 4 tipos de juegos estilo casino
tragamonedas, ruleta y mayor/menor.

Steps to Steps

El usuario loguea en el casino, y compra credito para poder jugar.
Elige siguiendo el menu, la opcion que desea entre las disponibles.
Una vez seleccionada la opcion/juego se dispone a realizar la/s apuesta/s correspondiente/s segun corresponda en cada ocacion.
siempre y cuando se cumplan una serie minima de requisitos (Saldo disponible en tarjeta y apuestas entre el minimo y maximo permitido por cada juego), el sistema
procedera a aceptar la apuesta y Jugara una tirada, se mostraran los resultados y acorde a ellos, si se ha ganado o no con respecto a su apuesta.
Puedes jugar siempre y cuando tu saldo de creditos sea mayor al minimo requerido.
El saldo se actualiza tras cada jugada, para mantener el valor siempre actualizado y visible para el usuario.
Puedes cambiar de juego cuantas veces quieras, pero no podras llevarte el credito a tu casa, si el sistema detecta que tienes saldo en credito, te obligara a pasar por
caja, para cambiarlo por efectivo!

Te estaremos esperando!
Grupo Error404